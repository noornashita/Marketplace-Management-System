<?php 
include('../config.php');

if (isset($_POST['name']) && isset($_POST['id'])) {
    $name = $_POST['name'];
    $id   = $_POST['id'];

    // Prepare statement for safety
    $stmt = $conn->prepare("UPDATE category SET name = ? WHERE id = ?");
    $stmt->bind_param("si", $name, $id);

    if ($stmt->execute()) {
        $data = array(
            'status' => 'true'
        );
    } else {
        $data = array(
            'status' => 'false',
            'error'  => $stmt->error
        );
    }

    $stmt->close();
    echo json_encode($data);
} else {
    echo json_encode(array(
        'status' => 'false',
        'error'  => 'Invalid request'
    ));
}
?>
