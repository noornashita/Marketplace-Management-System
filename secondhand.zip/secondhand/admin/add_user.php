<?php 
include('../config.php');

if (isset($_POST['name']) && !empty($_POST['name'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);

    $sql = "INSERT INTO `category` (`name`) VALUES ('$name')";
    $query = mysqli_query($conn, $sql);

    if ($query) {
        $data = array('status' => 'true');
    } else {
        $data = array('status' => 'false', 'error' => mysqli_error($conn));
    }
} else {
    $data = array('status' => 'false', 'error' => 'Name field empty');
}

echo json_encode($data);
?>
