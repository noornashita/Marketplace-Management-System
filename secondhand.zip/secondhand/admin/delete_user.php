<?php 
include('../config.php');

if (isset($_POST['id'])) {
    $category_id = $_POST['id'];

    // Prepare statement for safety
    $stmt = $conn->prepare("DELETE FROM category WHERE id = ?");
    $stmt->bind_param("i", $category_id);

    if ($stmt->execute()) {
        $data = array(
            'status' => 'success'
        );
    } else {
        $data = array(
            'status' => 'failed',
            'error'  => $stmt->error
        );
    }

    $stmt->close();
    echo json_encode($data);
} else {
    echo json_encode(array(
        'status' => 'failed',
        'error'  => 'Invalid request'
    ));
}
?>
