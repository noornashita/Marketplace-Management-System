<?php include('../config.php'); ?>
<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>Category List | Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap & DataTables CSS -->
  <link href="../css/bootstrap5.0.1.min.css" rel="stylesheet" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="../css/datatables-1.10.25.min.css" />
  <link rel="stylesheet" href="../css/menu.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

  <style>
    body {
      background-color: #fff;
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .header { background-color: #ffffff; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);}
    .navbar { display: flex; justify-content: space-between; align-items: center; padding: 10px 20px;}
    .navbar-brand { font-size: 28px; font-weight: bold; background: linear-gradient(45deg, #007BFF, #00C6FF);
      -webkit-background-clip: text; -webkit-text-fill-color: transparent; text-decoration: none; transition: transform 0.3s ease;}
    .navbar-brand:hover { transform: scale(1.05);}
    .navbar-menu { display: flex; align-items: center;}
    .navbar-list { list-style: none; display: flex; gap: 15px; margin: 0; padding: 0;}
    .navbar-link { text-decoration: none; color: #007BFF; font-weight: 500; padding: 8px 14px;
      border: 2px solid #007BFF; border-radius: 5px; transition: all 0.3s ease;}
    .navbar-link:hover { background-color: #007BFF; color: #fff;}
    .navbar-toggler { display: none; background: none; border: none; font-size: 20px;}
    @media (max-width: 768px) {
      .navbar-menu { display: none; flex-direction: column; background-color: #fff; position: absolute;
        top: 60px; right: 0; width: 200px; border: 1px solid #ddd; padding: 10px 0; z-index: 1000;}
      .navbar-menu.active { display: flex;}
      .navbar-toggler { display: block; cursor: pointer;}
      .navbar-list { flex-direction: column; gap: 10px;}
      .navbar-link { display: block; text-align: center;}
    }
    .card { border-radius: 10px; box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1); margin-top: 20px; padding: 20px; background: #fff;}
    .btnAdd { text-align: right; margin-bottom: 15px;}
    .btn-primary { background-color: #007BFF; border-color: #007BFF;}
    .btn-primary:hover { background-color: #0056b3; border-color: #004999;}
  </style>
</head>

<body>
  <!-- Navbar -->
  <header class="header">
    <nav class="navbar container">
      <a href="aCategory.php" class="navbar-brand">SecondHand Marketplace</a>
      <div class="navbar-menu">
        <ul class="navbar-list">
          <li><a href="aUserList.php" class="navbar-link">Customer List</a></li>
          <li><a href="aHome.php" class="navbar-link">Review Products</a></li>
          <li><a href="aCategory.php" class="navbar-link" style="font-weight:bold;">Category List</a></li>
          <li><a href="../logout.php" class="navbar-link">Logout</a></li>
        </ul>
      </div>
      <button class="navbar-toggler" aria-label="Toggle menu">
        <i class="fas fa-bars"></i>
      </button>
    </nav>
  </header>

  <!-- Category Section -->
  <div class="container">
    <div class="card">
      <div class="btnAdd">
        <a href="#!" data-bs-toggle="modal" data-bs-target="#addUserModal" class="btn btn-sm btn-primary">
          <i class="fas fa-plus"></i> Add Category
        </a>
      </div>
      <div class="table-responsive">
        <table id="example" class="table table-striped table-bordered">
          <thead class="table-light">
            <tr>
              <th>ID</th>
              <th>Category Name</th>
              <th>Options</th>
            </tr>
          </thead>
          <tbody></tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Scripts -->
  <script src="../javascript/jquery-3.6.0.min.js"></script>
  <script src="../javascript/bootstrap.bundle.min.js"></script>
  <script src="../javascript/dt-1.10.25datatables.min.js"></script>

  <script type="text/javascript">
    // Navbar Toggle
    document.addEventListener("DOMContentLoaded", function() {
      const toggler = document.querySelector(".navbar-toggler");
      const menu = document.querySelector(".navbar-menu");
      if (toggler && menu) {
        toggler.addEventListener("click", function() {
          menu.classList.toggle("active");
        });
      }
    });

    // DataTable
    $(document).ready(function() {
      $('#example').DataTable({
        "fnCreatedRow": function(nRow, aData, iDataIndex) {
          $(nRow).attr('id', aData[0]);
        },
        serverSide: true,
        processing: true,
        paging: true,
        order: [],
        ajax: {
          url: 'fetch_data.php',
          type: 'post',
        },
        columnDefs: [{
          orderable: false,
          targets: [2]
        }]
      });
    });

    // Add Category
    $(document).on('submit', '#addUser', function(e) {
      e.preventDefault();
      var name = $('#addNameField').val();
      if (name != '') {
        $.ajax({
          url: "add_user.php",
          type: "post",
          data: { name: name },
          success: function(data) {
            var json = JSON.parse(data);
            if (json.status == 'true') {
              $('#example').DataTable().draw();
              $('#addUserModal').modal('hide');
              $('#addUser')[0].reset();
            } else {
              alert('Failed: ' + (json.error ?? 'Unknown error'));
            }
          }
        });
      } else {
        alert('Fill all the required fields');
      }
    });

    // Update Category
    $(document).on('submit', '#updateUser', function(e) {
      e.preventDefault();
      var name = $('#nameField').val();
      var trid = $('#trid').val();
      var id = $('#id').val();
      if (name != '') {
        $.ajax({
          url: "update_user.php",
          type: "post",
          data: { name: name, id: id },
          success: function(data) {
            var json = JSON.parse(data);
            if (json.status == 'true') {
              var table = $('#example').DataTable();
              var button = '<td><a href="javascript:void();" data-id="' + id + '" class="btn btn-warning btn-sm editbtn">Edit</a> <a href="#!" data-id="' + id + '" class="btn btn-danger btn-sm deleteBtn">Delete</a></td>';
              var row = table.row("[id='" + trid + "']");
              row.data([id, name, button]);
              $('#exampleModal').modal('hide');
            } else {
              alert('Failed: ' + (json.error ?? 'Unknown error'));
            }
          }
        });
      } else {
        alert('Fill all the required fields');
      }
    });

    // Edit Button
    $('#example').on('click', '.editbtn ', function() {
      var trid = $(this).closest('tr').attr('id');
      var id = $(this).data('id');
      $('#exampleModal').modal('show');
      $.ajax({
        url: "get_single_data.php",
        data: { id: id },
        type: 'post',
        success: function(data) {
          var json = JSON.parse(data);
          $('#nameField').val(json.name);
          $('#id').val(id);
          $('#trid').val(trid);
        }
      })
    });

    // Delete Button
    $(document).on('click', '.deleteBtn', function() {
      var id = $(this).data('id');
      if (confirm("Are you sure want to delete this category?")) {
        $.ajax({
          url: "delete_user.php",
          data: { id: id },
          type: "post",
          success: function(data) {
            var json = JSON.parse(data);
            if (json.status == 'success') {
              $("#" + id).closest('tr').remove();
            } else {
              alert('Failed: ' + (json.error ?? 'Unknown error'));
            }
          }
        });
      }
    });
  </script>

  <!-- Update Modal -->
  <div class="modal fade" id="exampleModal" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Update Category</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <form id="updateUser">
            <input type="hidden" name="id" id="id">
            <input type="hidden" name="trid" id="trid">
            <div class="mb-3">
              <label for="nameField" class="form-label">Name</label>
              <input type="text" class="form-control" id="nameField" name="name">
            </div>
            <div class="text-center">
              <button type="submit" class="btn btn-primary">Submit</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- Add Modal -->
  <div class="modal fade" id="addUserModal" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Add Category</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <form id="addUser">
            <div class="mb-3">
              <label for="addNameField" class="form-label">Name</label>
              <input type="text" class="form-control" id="addNameField" name="name">
            </div>
            <div class="text-center">
              <button type="submit" class="btn btn-primary">Submit</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

</body>
</html>
