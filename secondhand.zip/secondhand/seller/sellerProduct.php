<?php 
session_start();
$email = $_SESSION['email'];
include_once('../config.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>My Products | Seller</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- DataTables -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">

<!-- FontAwesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<!-- Bootstrap (needed for modal) -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<style>
    body {
        background-color: #f5f8fc;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        margin: 0;
    }

    /* Navbar */
    .header {
        background-color: #ffffff;
        box-shadow: 0 2px 6px rgba(0,0,0,0.1);
        position: sticky;
        top: 0;
        z-index: 100;
    }
    .navbar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px 25px;
    }

    .navbar-brand {
        font-size: 28px;
        font-weight: bold;
        background: linear-gradient(45deg, #007BFF, #00C6FF);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-decoration: none;
    }

    .navbar-list {
        list-style: none;
        display: flex;
        gap: 15px;
        margin: 0;
        padding: 0;
    }
    .navbar-link {
        text-decoration: none;
        color: #007BFF;
        font-weight: 500;
        padding: 8px 14px;
        border: 2px solid #007BFF;
        border-radius: 6px;
        transition: 0.3s;
    }
    .navbar-link:hover {
        background-color: #007BFF;
        color: #fff;
    }
    .navbar-link.active {
        background-color: #007BFF;
        color: white !important;
    }

    /* Buttons (Center Aligned FIXED) */
    .btn-group {
        text-align: center;  /* CENTER FIX */
        margin: 25px 0;
        width: 100%;
    }
    .btn-group button {
        background-color: #007BFF;
        border: none;
        color: white;
        margin: 5px;
        cursor: pointer;
        width: 160px;
        height: 45px;
        border-radius: 6px;
        transition: 0.3s;
        font-size: 15px;
        display: inline-block;
    }
    .btn-group button:hover {
        background-color: #0056b3;
        transform: scale(1.03);
    }

    /* Main Card */
    .chris {
        margin: 0px 40px 50px 40px;
        background: #fff;
        padding: 25px;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }

    /* Table */
    table.dataTable thead th {
        background-color: #007BFF;
        color: #fff;
        text-align: center;
    }
    table.dataTable tbody td {
        text-align: center;
        vertical-align: middle;
    }
    .table-img {
        width: 60px;
        height: 60px;
        object-fit: cover;
        border-radius: 6px;
    }

    .action-btn {
        padding: 6px 12px;
        margin: 2px;
        border-radius: 6px;
        text-decoration: none;
        color: white !important;
        font-size: 14px;
    }

    .btn-edit { background: #28a745; }
    .btn-edit:hover { background: #1f7e34; }

    .btn-onoff { background: #ffc107; color: black !important; }
    .btn-onoff:hover { background: #d9a406; }

    footer {
        text-align: center;
        padding: 15px;
        background-color: #f8f9fa;
        margin-top: 40px;
    }
</style>
</head>
<body>

<!-- Navbar -->
<header class="header">
    <nav class="navbar">
        <a href="../index.php" class="navbar-brand">SecondHand Marketplace</a>
        <ul class="navbar-list">
            <li><a href="sellerMain.php" class="navbar-link">Home</a></li>
            <li><a href="sellerProduct.php" class="navbar-link active">My Products</a></li>
            <li><a href="sellerOrder.php" class="navbar-link">My Orders</a></li>
            <li><a href="income.php" class="navbar-link">My Income</a></li>
            <li><a href="../logout.php" class="navbar-link">Logout</a></li>
        </ul>
    </nav>
</header>

<!-- Product Buttons (CENTER FIXED) -->
<div class="btn-group">
    <button onclick="location.href='sellerProduct.php'"><i class="fa fa-box"></i> All Product</button>
    <button onclick="location.href='addProduct.php'"><i class="fa fa-plus-circle"></i> Add Product</button>
    <button onclick="location.href='pendingList.php'"><i class="fa fa-clock"></i> Pending List</button>
    <button onclick="location.href='declineList.php'"><i class="fa fa-times-circle"></i> Decline List</button>
</div>

<!-- Main Container -->
<div class="chris">
    <table id="example" class="display">
        <thead>
            <tr>
                <th>Image</th>
                <th>ID</th>
                <th>Title</th>
                <th>Category</th>
                <th>Quantity</th>
                <th>Price (BDT)</th>
                <th>Description</th>
                <th>Shelf</th>
                <th>Action</th>
            </tr>
        </thead>

        <tbody>
        <?php
        $sql = "SELECT * FROM product WHERE seller_id='$email' AND status='Approve'";
        $query = $conn->query($sql);

        while($row = $query->fetch_assoc()){
            echo "
            <tr>
                <td><img class='table-img' src='../images/".$row['image']."'></td>
                <td>".$row['id']."</td>
                <td>".$row['title']."</td>
                <td>".$row['category']."</td>
                <td>".$row['quantity']."</td>
                <td>".$row['price']."</td>
                <td>".$row['description']."</td>
                <td>".$row['shelf']."</td>
                <td>
                    <a href='#edit_".$row['id']."' class='action-btn btn-edit' data-toggle='modal'>Edit</a>
                    <a href='#delete_".$row['id']."' class='action-btn btn-onoff' data-toggle='modal'>On/Off</a>
                </td>
            </tr>
            ";
            include('editquantity_onoffshelf_modal.php');
        }
        ?>
        </tbody>

        <tfoot>
            <tr>
                <th>Image</th>
                <th>ID</th>
                <th>Title</th>
                <th>Category</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Description</th>
                <th>Shelf</th>
                <th>Action</th>
            </tr>
        </tfoot>
    </table>
</div>

<footer>
    <p>&copy; <script>document.write(new Date().getFullYear());</script> Second Hand Shopping Platform</p>
</footer>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
$(document).ready(function() {
    $('#example').DataTable();
});
</script>

</body>
</html>
