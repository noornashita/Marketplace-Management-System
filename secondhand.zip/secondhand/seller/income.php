<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>My Income | Seller</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

  <!-- Datatable CSS -->
  <link href='../css/datatables.min.css' rel='stylesheet' type='text/css'>
  <link rel="stylesheet" type="text/css" href="../css/jquery-ui.min.css">

  <!-- jQuery Library -->
  <script src="../javascript/jquery-3.4.1.min.js"></script>
  <script type="text/javascript" src="../javascript/jquery-ui.min.js"></script>
  <!-- Datatable JS -->
  <script src="../javascript/datatables.min.js"></script>

  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f8f9fa;
    }

    /* Navbar */
    .header {
      background-color: #ffffff;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      position: sticky;
      top: 0;
      z-index: 1000;
    }
    .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 12px 20px;
    }
    .navbar-brand {
      font-size: 24px;
      font-weight: bold;
      background: linear-gradient(45deg, #007BFF, #00C6FF);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      text-decoration: none;
    }
    .navbar-list {
      list-style: none;
      display: flex;
      gap: 15px;
      margin: 0;
      padding: 0;
    }
    .navbar-link {
      text-decoration: none;
      color: #007BFF;
      font-weight: 500;
      padding: 8px 14px;
      border: 2px solid #007BFF;
      border-radius: 6px;
      transition: all 0.3s ease;
    }
    .navbar-link:hover {
      background-color: #007BFF;
      color: #fff;
    }

    /* Content Box */
    .content-wrapper {
      max-width: 1100px;
      margin: 30px auto;
      padding: 25px;
      background: #fff;
      border-radius: 10px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    }
    h2 {
      text-align: center;
      margin-bottom: 20px;
      color: #007BFF;
    }

    /* Date Filter */
    .filter-box {
      display: flex;
      justify-content: center;
      gap: 10px;
      margin-bottom: 20px;
      flex-wrap: wrap;
    }
    input[type="text"] {
      padding: 8px 10px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 15px;
    }
    #btn_search {
      background-color: #007BFF;
      border: none;
      color: white;
      padding: 8px 20px;
      font-size: 15px;
      border-radius: 6px;
      cursor: pointer;
      transition: background 0.3s ease;
    }
    #btn_search:hover {
      background-color: #0056b3;
    }

    /* DataTable */
    table.dataTable {
      width: 100% !important;
      border-collapse: collapse;
    }
    table.dataTable th {
      background-color: #007BFF;
      color: #fff;
      text-align: center;
      padding: 10px;
    }
    table.dataTable td {
      padding: 10px;
      text-align: center;
      border-bottom: 1px solid #e9ecef;
    }
    tfoot th {
      font-weight: bold;
      text-align: right;
      padding: 10px;
      background-color: #f1f3f6;
    }

    footer {
      text-align: center;
      padding: 15px;
      background-color: #f8f9fa;
      margin-top: 30px;
      font-size: 14px;
      color: #555;
    }
  </style>
</head>
<body>

<!-- Navbar -->
<header class="header">
  <nav class="navbar">
    <a href="sellerMain.php" class="navbar-brand">SecondHand Marketplace</a>
    <ul class="navbar-list">
      <!--<li><a href="../buyer/buyerMain.php" class="navbar-link">Buyer Centre</a></li>-->
      <li><a href="sellerMain.php" class="navbar-link">Home</a></li>
      <li><a href="sellerProduct.php" class="navbar-link">My Product</a></li>
      <li><a href="sellerOrder.php" class="navbar-link">My Order</a></li>
      <li><a href="income.php" class="navbar-link">My Income</a></li>
      <li><a href="../logout.php" class="navbar-link">Logout</a></li>
    </ul>
  </nav>
</header>

<!-- Content -->
<div class="content-wrapper">
  <h2>My Income History</h2>

  <!-- Date Filter -->
  <div class="filter-box">
    <input type='text' readonly id='search_fromdate' class="datepicker" placeholder='From date'>
    <input type='text' readonly id='search_todate' class="datepicker" placeholder='To date'>
    <button id="btn_search">Search</button>
  </div>

  <!-- Table -->
  <table id='empTable' class='display dataTable'>
    <thead>
      <tr>
        <th>Date & Time</th>
        <th>Transaction History</th>
        <th>Amount (BDT)</th>
      </tr>
    </thead>
    <tfoot>
      <tr>
        <th></th>
        <th style="text-align:right">Total Price (BDT):</th>
        <th></th>
      </tr>
    </tfoot>
  </table>
</div>

<!-- Footer -->
<footer>
  <p>Copyright &copy; 
    <script>document.write(new Date().getFullYear());</script> 
    Second Hand Shopping Platform
  </p>
</footer>

<!-- Script -->
<script>
$(document).ready(function(){

    // Datapicker 
    $( ".datepicker" ).datepicker({
        "dateFormat": "yy-mm-dd",
        changeYear: true
    });

    // DataTable
    var dataTable = $('#empTable').DataTable({
        'processing': true,
        'serverSide': true,
        'serverMethod': 'post',
        'searching': true,
        'ajax': {
            'url':'ajaxfile.php',
            'data': function(data){
                var from_date = $('#search_fromdate').val();
                var to_date = $('#search_todate').val();
                data.searchByFromdate = from_date;
                data.searchByTodate = to_date;
            }
        },
        'columns': [
            { data: 'time' },
            {
                "data": "transaction_id",
                "render": function(data, type, row, meta) {
                    return `Income from Order #${row.transaction_id}`;
                }
            },
            {
                "data": "totalPrice",
                "render": function(data, type, row, meta) {
                    return `+ ${row.totalPrice}`;
                }
            },
        ],
        footerCallback: function(tfoot, data, start, end, display) {
          var api = this.api();
          $(api.column(2).footer()).html(
             api.column(2).data().reduce(function(a,b) {
                return (+a + +b);
             }, 0)
          );
       }
    });

    // Search button
    $('#btn_search').click(function(){
        dataTable.draw();
    });
});
</script>

</body>
</html>
