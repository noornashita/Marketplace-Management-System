<?php
include '../config.php';
session_start();
$email = $_SESSION['email'];

$sqli = "SELECT COUNT(*) AS countquantity FROM cart WHERE email='$email'";
$duration = $conn->query($sqli);
$record = $duration->fetch_array();
$totalquantity = $record['countquantity'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cancelled Orders | Seller</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Font Awesome + DataTables -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">

    <style>
        body {
            background-color: #f5f8fc;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
        }
        /* Navbar */
        .header {
            background-color: #ffffff;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 25px;
        }
        .navbar-brand {
            font-size: 28px;
            font-weight: bold;
            background: linear-gradient(45deg, #007BFF, #00C6FF);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-decoration: none;
        }
        .navbar-list {
            list-style: none;
            display: flex;
            gap: 15px;
            margin: 0;
            padding: 0;
        }
        .navbar-link {
            text-decoration: none;
            color: #007BFF;
            font-weight: 500;
            padding: 8px 14px;
            border: 2px solid #007BFF;
            border-radius: 6px;
            transition: 0.3s;
        }
        .navbar-link:hover {
            background-color: #007BFF;
            color: #fff;
        }
        /* Buttons */
        .btn-group {
            text-align: center;
            margin: 25px 0;
        }
        .btn-group button {
            background-color: #007BFF;
            border: none;
            color: white;
            margin: 5px;
            cursor: pointer;
            width: 150px;
            height: 45px;
            border-radius: 6px;
            transition: 0.3s;
        }
        .btn-group button:hover {
            background-color: #0056b3;
        }
        /* Table Card */
        .chris {
            margin: 0px 40px 50px 40px;
            background: #fff;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        table.dataTable {
            width: 100% !important;
            border-collapse: collapse;
        }
        table.dataTable thead th {
            background-color: #007BFF;
            color: #fff;
            text-align: center;
        }
        table.dataTable tbody td {
            text-align: center;
        }
        select, input[type=submit] {
            padding: 6px 10px;
            border-radius: 6px;
            border: 1px solid #ccc;
        }
        input[type=submit] {
            background: #007BFF;
            border: none;
            color: #fff;
            cursor: pointer;
            margin-top: 5px;
        }
        input[type=submit]:hover {
            background: #0056b3;
        }
        footer {
            text-align: center;
            padding: 15px;
            background-color: #f8f9fa;
            margin-top: 40px;
        }
    </style>
</head>
<body>
<header class="header">
    <nav class="navbar">
        <a href="../index.php" class="navbar-brand">SecondHand Marketplace</a>
        <ul class="navbar-list">
            <!--<li><a href="../buyer/buyerMain.php" class="navbar-link">Buyer Centre</a></li>-->
            <li><a href="sellerMain.php" class="navbar-link">Home</a></li>
            <li><a href="sellerProduct.php" class="navbar-link">My Products</a></li>
            <li><a href="sellerOrder.php" class="navbar-link">My Orders</a></li>
            <li><a href="income.php" class="navbar-link">My Income</a></li>
            <li><a href="../logout.php" class="navbar-link">Logout</a></li>
        </ul>
    </nav>
</header>

<div class="btn-group">
    <button onclick="location.href='sellerOrder.php'">All</button>
    <button onclick="location.href='sellerOrder_pending.php'">Pending</button>
    <button onclick="location.href='sellerOrder_to_received.php'">To Received</button>
    <button onclick="location.href='sellerOrder.completed.php'">Completed</button>
    <button onclick="location.href='sellerOrder_cancelled.php'" style="background:#0056b3;">Cancelled</button>
</div>

<div class="card">
    <!--<h2>Cancelled Orders</h2>
    <p>Below is the list of orders that have been cancelled. You can still update their status if needed.</p>-->

    <table id="example" class="display">
        <thead>
            <tr>
                <th>Date & Time</th>
                <th>Transaction ID</th>
                <th>Address</th>
                <th>Image</th>
                <th>Name</th>
                <th>Total Price (BDT)</th>
                <th>Payment Status</th>
                <th>Order Status</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $query = "SELECT * FROM order_list WHERE seller_id = '$email' AND order_status='Cancelled' ORDER BY time DESC";
        $result = mysqli_query($conn, $query);
        while($row = mysqli_fetch_array($result)){
        ?>
            <tr>
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                <input name="transaction_id" type="hidden" value ="<?php echo $row['transaction_id'];?>">

                <td><?php echo $row['time'];?></td>
                <td><?php echo $row['transaction_id'];?><br><small><b><?php echo $row['custemail'];?></b></small></td>
                <td><?php echo $row['delivery_address'].', '.$row['street'].', '.$row['area'];?></td>
                <td style="width:120px;"><img src="../images/<?php echo $row['image'] ?>" width="100%"></td>
                <td><?php echo $row['title'];?><br><b>x<?php echo $row['quantity'];?></b></td>
                <td><?php echo $row['totalPrice'];?></td>
                <td><?php echo $row['payment_status'];?></td>
                <td>
                  <select name="colorList">
                    <option <?php if($row['order_status']=='Pending') echo"selected"; ?>>Pending</option>
                    <option <?php if($row['order_status']=='To Received') echo"selected"; ?>>To Received</option>
                    <option <?php if($row['order_status']=='Completed') echo"selected"; ?>>Completed</option>
                    <option <?php if($row['order_status']=='Cancelled') echo"selected"; ?>>Cancelled</option>
                  </select>
                  <br><input type="submit" name="btnSubmit" value="Update">
            </form>
                </td>
            </tr>
        <?php } ?>
        </tbody>
        <tfoot>
            <tr>
                <th>Date & Time</th>
                <th>Transaction ID</th>
                <th>Address</th>
                <th>Image</th>
                <th>Name</th>
                <th>Total Price (BDT)</th>
                <th>Payment Status</th>
                <th>Order Status</th>
            </tr>
        </tfoot>
    </table>
</div>

<footer>
    <p>&copy; <script>document.write(new Date().getFullYear());</script> Second Hand Shopping Platform</p>
</footer>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
<script>
$(document).ready(function() {
    $('#example').DataTable();
});
</script>
</body>
<?php
  if(isset($_POST['btnSubmit'])){
    if(isset($_POST['colorList'])){
      $value=$_POST['colorList'];
      $value1=$_POST['transaction_id'];
      $sql = "UPDATE order_list SET order_status='$value' WHERE transaction_id='$value1';";
      if (mysqli_query($conn, $sql)) {
          echo '<script>window.location.href = window.location.href;</script>';
      } else {
          echo "Error: " . $sql . "<br>" . mysqli_error($conn);
      }
    }
  }
?>
</html>
