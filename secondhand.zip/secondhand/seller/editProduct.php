<?php
include '../config.php';
session_start();

if(!isset($_SESSION['email'])){
    header("Location: ../login.php");
    exit();
}

$email = $_SESSION['email'];

// Fetch product details if pid is set
if(isset($_GET['pid'])){
    $pid = $_GET['pid'];
    $sql = "SELECT * FROM product WHERE id='$pid'";
    $result = $conn->query($sql);
}

// Fetch categories
$sqlCat = "SELECT * FROM category";
$resultCat = $conn->query($sqlCat);

// Handle form submission
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $id = $_POST["id"];
    $title = $_POST["title"];
    $category = $_POST["category"];
    $description = $_POST["description"];
    $quantity = $_POST["quantity"];
    $price = $_POST["price"];
    $image = $_POST["image"]; // default image from hidden input

    // Handle file upload if new image provided
    if(isset($_FILES['fileToUpload']) && $_FILES['fileToUpload']['error'] == 0){
        $image = basename($_FILES["fileToUpload"]["name"]);
        $target_dir = "images/";
        $target_file = $target_dir . $image;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        $uploadOk = 1;

        $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
        if($check !== false){
            $uploadOk = 1;
        } else { $uploadOk = 0; }

        if($_FILES["fileToUpload"]["size"] > 2000000) $uploadOk = 0;
        if(!in_array($imageFileType, ['jpg','jpeg','png','gif'])) $uploadOk = 0;

        if($uploadOk == 1){
            move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file);
        } else {
            echo "<script>alert('Image upload failed or invalid format.');</script>";
        }
    }

    // Update product in DB
    $updateSQL = "UPDATE product SET title='$title', category='$category', description='$description', quantity='$quantity', price='$price', image='$image', status='Pending', reason='', shelf='off' WHERE id='$id'";
    if(mysqli_query($conn, $updateSQL)){
        echo "<script>alert('Product Updated Successfully!'); window.location.href='sellerProduct.php';</script>";
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Product | Seller</title>
<link rel="stylesheet" href="../css/menu.css">
<style>
body{
    background:#f5f8fc;
    font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    margin:0;
}
.header{
    background:#004aad;
    color:#fff;
    padding:15px 20px;
    display:flex;
    align-items:center;
    justify-content:space-between;
}
.header a{
    color:white;
    text-decoration:none;
    font-weight:bold;
}
.wrapper{
    max-width:700px;
    margin:30px auto;
    background:white;
    padding:30px;
    border-radius:12px;
    box-shadow:0 4px 12px rgba(0,0,0,0.1);
}
.wrapper h1{
    color:#004aad;
    text-align:center;
    margin-bottom:20px;
}
.form-group{
    margin-bottom:15px;
}
.form-group label{
    font-weight:bold;
    color:#004aad;
}
.form-group input[type=text],
.form-group input[type=number],
.form-group select,
.form-group textarea{
    width:100%;
    padding:10px;
    border:1px solid #ccc;
    border-radius:8px;
    margin-top:5px;
    font-size:15px;
}
.form-group textarea{
    resize:none;
    height:120px;
}
.form-group img{
    max-width:120px;
    margin-top:10px;
    border-radius:8px;
}
input[type=submit]{
    width:100%;
    padding:12px;
    background:#004aad;
    color:white;
    border:none;
    border-radius:8px;
    font-size:18px;
    cursor:pointer;
}
input[type=submit]:hover{
    background:#0066ff;
}
@media screen and (max-width:600px){
    .wrapper{padding:20px;}
}
</style>
</head>
<body>
<header class="header">
    <a href="sellerMain.php">Seller Dashboard</a>
    <a href="../logout.php">Logout</a>
</header>

<div class="wrapper">
<h1>Edit Product</h1>
<?php
if($result->num_rows > 0){
    $row = $result->fetch_assoc();
?>
<form method="post" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
    <input type="hidden" name="image" value="<?php echo $row['image']; ?>">
    
    <div class="form-group">
        <label>Product Title</label>
        <input type="text" name="title" value="<?php echo $row['title']; ?>" required>
    </div>
    <div class="form-group">
        <label>Category</label>
        <select name="category" required>
            <option value="" disabled>Select Category</option>
            <option value="Dress" <?php if(($_POST['type'] ?? '')=='Dress') echo 'selected'; ?>>Dress</option>
            <option value="Shoes" <?php if(($_POST['type'] ?? '')=='Shoes') echo 'selected'; ?>>Shoes</option>
    
            <?php while($cat = $resultCat->fetch_assoc()){ ?>
                <option value="<?php echo $cat['name']; ?>" <?php if($cat['name']==$row['category']) echo 'selected'; ?>><?php echo $cat['name']; ?></option>
            <?php } ?>
        </select>
    </div>
    <div class="form-group">
        <label>Quantity</label>
        <input type="number" name="quantity" value="<?php echo $row['quantity']; ?>" required>
    </div>
    <div class="form-group">
        <label>Price (BDT)</label>
        <input type="number" name="price" value="<?php echo $row['price']; ?>" step="0.01" required>
    </div>
    <div class="form-group">
        <label>Description</label>
        <textarea name="description" required><?php echo $row['description']; ?></textarea>
    </div>
    <div class="form-group">
        <label>Product Image</label>
        <input type="file" name="fileToUpload" onchange="showPreview(event)">
        <img id="preview" src="images/<?php echo $row['image']; ?>" alt="Product Image">
    </div>
    <input type="submit" value="Update Product">
</form>
<?php } ?>
</div>

<script>
function showPreview(event){
    if(event.target.files.length > 0){
        var src = URL.createObjectURL(event.target.files[0]);
        document.getElementById("preview").src = src;
    }
}
</script>
</body>
</html>
