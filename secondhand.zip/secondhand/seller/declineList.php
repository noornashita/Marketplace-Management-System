<?php
include '../config.php';
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Decline List | Seller</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f8f9fa;
    }

    /* Navbar */
    .header {
      background-color: #ffffff;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      position: sticky;
      top: 0;
      z-index: 1000;
    }
    .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 12px 20px;
    }
    .navbar-brand {
      font-size: 26px;
      font-weight: bold;
      background: linear-gradient(45deg, #007BFF, #00C6FF);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      text-decoration: none;
    }
    .navbar-list {
      list-style: none;
      display: flex;
      gap: 15px;
      margin: 0;
      padding: 0;
    }
    .navbar-link {
      text-decoration: none;
      color: #007BFF;
      font-weight: 500;
      padding: 8px 14px;
      border: 2px solid #007BFF;
      border-radius: 6px;
      transition: all 0.3s ease;
    }
    .navbar-link:hover {
      background-color: #007BFF;
      color: #fff;
    }

    /* Button group */
    .btn-group {
      text-align: center;
      margin: 30px 0;
    }
    .btn-group button {
      background-color: #007BFF;
      border: none;
      color: white;
      padding: 12px 20px;
      margin: 5px;
      font-size: 16px;
      border-radius: 6px;
      cursor: pointer;
      transition: 0.3s;
    }
    .btn-group button:hover {
      background-color: #0056b3;
    }

    /* Table */
    .center {
      margin: auto;
      width: 95%;
      padding: 20px;
      background: #fff;
      border-radius: 8px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
      overflow-x: auto;
    }
    table {
      border-collapse: collapse;
      width: 100%;
    }
    th, td {
      text-align: center;
      padding: 12px;
      border-bottom: 1px solid #ddd;
    }
    th {
      background-color: #007BFF;
      color: white;
    }
    tr:hover {
      background-color: #f1f1f1;
    }

    /* Action buttons */
    .action-edit {
      background-color: #f39c12;
      color: white;
      border: none;
      padding: 10px 16px;
      border-radius: 6px;
      cursor: pointer;
      font-size: 14px;
      text-decoration: none;
      margin-right: 5px;
      display: inline-block;
    }
    .action-edit:hover {
      background-color: #d68910;
    }
    .action-delete {
      background-color: #e74c3c;
      color: white;
      border: none;
      padding: 10px 16px;
      border-radius: 6px;
      cursor: pointer;
      font-size: 14px;
    }
    .action-delete:hover {
      background-color: #c0392b;
    }

    footer {
      text-align: center;
      padding: 15px;
      margin-top: 30px;
      background-color: #f8f9fa;
      color: #555;
      font-size: 14px;
    }
  </style>
</head>
<body>

<!-- Navbar -->
<header class="header">
  <nav class="navbar">
    <a href="sellerMain.php" class="navbar-brand">SecondHand Marketplace</a>
    <ul class="navbar-list">
      <li><a href="../buyer/buyerMain.php" class="navbar-link">Buyer Centre</a></li>
      <li><a href="sellerMain.php" class="navbar-link">Home</a></li>
      <li><a href="sellerProduct.php" class="navbar-link">My Product</a></li>
      <li><a href="sellerOrder.php" class="navbar-link">My Order</a></li>
      <li><a href="income.php" class="navbar-link">My Income</a></li>
      <li><a href="../logout.php" class="navbar-link">Logout</a></li>
    </ul>
  </nav>
</header>

<!-- Button group -->
<div class="btn-group">
  <button onclick="location.href='sellerProduct.php'">All Product</button>
  <button onclick="location.href='addProduct.php'">Add New Product</button>
  <button onclick="location.href='pendingList.php'">Pending List</button>
  <button onclick="location.href='declineList.php'">Decline List</button>
</div>

<!-- Table -->
<div class="center">
  <h2 style="color:#007BFF; margin-bottom:20px;">Declined Product List</h2>
  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Title</th>
        <th>Category</th>
        <th>Quantity</th>
        <th>Price</th>
        <th>Image</th>
        <th>Description</th>
        <th>Reason</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php
        $seller_id = $_SESSION['email'];
        $query = "SELECT * FROM product WHERE status = 'decline' AND seller_id = '$seller_id' ORDER BY id ASC";
        $result = mysqli_query($conn, $query);
        while($row = mysqli_fetch_array($result)){
          $id=$row['id'];
          $title=$row['title'];
          $category=$row['category'];
          $quantity=$row['quantity'];
          $price=$row['price'];
          $image=$row['image'];
          $description=$row['description'];
          $reason=$row['reason'];
      ?>
      <tr>
        <td><?php echo $id; ?></td>
        <td><?php echo $title; ?></td>
        <td><?php echo $category; ?></td>
        <td><?php echo $quantity; ?></td>
        <td><?php echo 'BDT '.$price; ?></td>
        <td><img src="../images/<?php echo $image ?>" alt="Product Image" style="max-width:100px; border-radius:6px;"></td>
        <td><?php echo $description; ?></td>
        <td style="color:#e74c3c; font-weight:bold;"><?php echo $reason; ?></td>
        <td>
          <a href="editProduct.php?pid=<?php echo $id; ?>" class="action-edit"><i class="fa fa-edit"></i> Edit</a>
          <form action="declineList.php" method="POST" style="display:inline-block;">
            <input type="hidden" name="id" value="<?php echo $id; ?>"/>
            <input type="submit" name="delete" value="Delete" class="action-delete"/>
          </form>
        </td>
      </tr>
      <?php } ?>
    </tbody>
  </table>
</div>

<!-- Footer -->
<footer>
  <p>Copyright &copy; <script>document.write(new Date().getFullYear());</script> Second Hand Shopping Platform</p>
</footer>

</body>
</html>

<?php
if(isset($_POST['delete'])){
    $id = $_POST['id'];
    $select = "DELETE FROM product WHERE id = '$id'";
    $result = mysqli_query($conn, $select);

    echo '<script type="text/javascript">';
    echo 'alert("Product Deleted!");';
    echo 'window.location.href = "declineList.php";';
    echo '</script>';
}
?>
