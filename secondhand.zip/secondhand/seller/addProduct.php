<?php
include '../config.php';
session_start();

// Generate custom product ID
$query2 = "SELECT * FROM product ORDER BY id DESC LIMIT 1";
$result2 = mysqli_query($conn, $query2);
$row = mysqli_fetch_array($result2);
$last_id = $row['id'] ?? 0;

$code = rand(10000, 99999);
$char = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
$code2 = substr(str_shuffle($char), 0, 3);
$customer_ID = $code2 . "_" . $code;

// Insert product
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST["id"];
    $title = $_POST["title"];
    $category = $_POST["category"];
    $description = $_POST["description"];
    $quantity = $_POST["quantity"];
    $price = $_POST["price"];
    $seller_id = $_SESSION['email'];
    $seller_username = $_SESSION['username'];

    // Image Upload
    $image = basename($_FILES["fileToUpload"]["name"]);
    $target_dir = "../images/";
    $target_file = $target_dir . $image;
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    if (!empty($_FILES["fileToUpload"]["tmp_name"])) {
        $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
        if ($check === false) {
            echo "<script>alert('File is not an image.');</script>";
            $uploadOk = 0;
        }
    }

    if ($_FILES["fileToUpload"]["size"] > 2000000) {
        echo "<script>alert('Sorry, your file is too large.');</script>";
        $uploadOk = 0;
    }

    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
        echo "<script>alert('Sorry, only JPG, JPEG, PNG files are allowed.');</script>";
        $uploadOk = 0;
    }

    if ($uploadOk == 1) {
        if (!move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
            echo "<script>alert('Sorry, there was an error uploading your file.');</script>";
        }
    }

    // Insert into DB
    $sql = "INSERT INTO product (id,title,category,description,quantity,price,image,seller_id,seller_username) 
            VALUES ('$id','$title','$category','$description','$quantity','$price','$image','$seller_id','$seller_username')";
    if (mysqli_query($conn, $sql)) {
        $kobe = "Product Added Successfully!";
    } else {
        echo "<script>alert('Database Error: " . mysqli_error($conn) . "');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Product | Seller</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../css/toastr.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<script src="../javascript/jquery-3.3.1.min.js"></script>
<script src="../javascript/toastr.min.js"></script>
<style>
    body {
        background-color: #f5f8fc;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        margin: 0;
    }
    .header {
        background-color: #ffffff;
        box-shadow: 0 2px 6px rgba(0,0,0,0.1);
        position: sticky;
        top: 0;
        z-index: 100;
    }
    .navbar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px 25px;
    }
    .navbar-brand {
        font-size: 28px;
        font-weight: bold;
        background: linear-gradient(45deg, #007BFF, #00C6FF);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-decoration: none;
    }
    .navbar-list {
        list-style: none;
        display: flex;
        gap: 15px;
        margin: 0;
        padding: 0;
    }
    .navbar-link {
        text-decoration: none;
        color: #007BFF;
        font-weight: 500;
        padding: 8px 14px;
        border: 2px solid #007BFF;
        border-radius: 6px;
        transition: 0.3s;
    }
    .navbar-link:hover {
        background-color: #007BFF;
        color: #fff;
    }
    .form-container {
        max-width: 900px;
        margin: 30px auto;
        background: #fff;
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    h2 {
        color: #007BFF;
        margin-bottom: 20px;
        text-align: center;
    }
    input[type=text],
    input[type=number],
    select,
    textarea {
        width: 100%;
        padding: 10px;
        margin-bottom: 18px;
        border: 1px solid #ccc;
        border-radius: 6px;
        transition: 0.3s;
    }
    input:focus, select:focus, textarea:focus {
        border-color: #007BFF;
        outline: none;
        box-shadow: 0 0 4px rgba(0,123,255,0.4);
    }
    textarea {
        resize: vertical;
        height: 120px;
    }
    .submit-btn {
        background-color: #007BFF;
        border: none;
        padding: 14px;
        width: 100%;
        color: white;
        font-size: 16px;
        border-radius: 6px;
        cursor: pointer;
        transition: 0.3s;
    }
    .submit-btn:hover {
        background-color: #0056b3;
    }
    .preview-box {
        text-align: center;
        margin-top: 15px;
    }
    .preview-box img {
        max-height: 150px;
        border-radius: 8px;
        margin-top: 10px;
    }
    footer {
        text-align: center;
        padding: 15px;
        background-color: #f8f9fa;
        margin-top: 40px;
    }
</style>
</head>
<body>
<header class="header">
    <nav class="navbar">
        <a href="../index.php" class="navbar-brand">SecondHand Marketplace</a>
        <ul class="navbar-list">
            <!--<li><a href="../buyer/buyerMain.php" class="navbar-link">Buyer Centre</a></li>-->
            <li><a href="sellerMain.php" class="navbar-link">Home</a></li>
            <li><a href="sellerProduct.php" class="navbar-link">My Products</a></li>
            <li><a href="sellerOrder.php" class="navbar-link">My Orders</a></li>
            <li><a href="income.php" class="navbar-link">My Income</a></li>
            <li><a href="../logout.php" class="navbar-link">Logout</a></li>
        </ul>
    </nav>
</header>

<div class="form-container">
    <form method="post" enctype="multipart/form-data">
        <h2>Add New Product</h2>
        <input type="text" name="id" value="<?php echo $customer_ID; ?>" readonly>
        <input type="text" name="title" placeholder="Product Name" required>
        <select name="category" required>
            <option value="" disabled selected>Select Category</option>
             <option value="Dress" <?php if(($_POST['type'] ?? '')=='Dress') echo 'selected'; ?>>Dress</option>
            <option value="Shoes" <?php if(($_POST['type'] ?? '')=='Shoes') echo 'selected'; ?>>Shoes</option>
            <option value="Cap" <?php if(($_POST['type'] ?? '')=='cap') echo 'selected'; ?>>Cap</option>
             <option value="Headphone" <?php if(($_POST['type'] ?? '')=='Headphone') echo 'selected'; ?>>Headphone</option>
            <option value="Jewellery" <?php if(($_POST['type'] ?? '')=='Jewellery') echo 'selected'; ?>>Jewellery</option>
    
            <?php
            $sql5 = "SELECT * FROM category";
            $result5 = $conn->query($sql5);
            if ($result5 && $result5->num_rows > 0) {
                while ($row = $result5->fetch_assoc()) {
                    $name = $row['name'];
                    echo "<option value='$name'>$name</option>";
                }
            }
            ?>
        </select>
        <input type="number" name="quantity" placeholder="Quantity" required>
        <input type="number" name="price" placeholder="Price" required>
        <label><b>Upload Product Image</b></label>
        <input type="file" id="fileToUpload" name="fileToUpload" onchange="showPreview(event);" required>

        <div class="preview-box">
            <img id="fileToUpload-preview" style="display:none;">
        </div>

        <label><b>Product Description</b></label>
        <textarea id="description" name="description" placeholder="Enter product details..." required></textarea>

        <?php if (!empty($kobe)) {echo "<p style='color:green;text-align:center;font-weight:bold;'>$kobe</p>";} ?>

        <input type="submit" name="submit" class="submit-btn" value="Add Product">
    </form>
</div>

<footer>
    <p>&copy; <script>document.write(new Date().getFullYear());</script> Second Hand Shopping Platform</p>
</footer>

<script>
function showPreview(event){
  if(event.target.files.length > 0){
    var src = URL.createObjectURL(event.target.files[0]);
    var preview = document.getElementById("fileToUpload-preview");
    preview.src = src;
    preview.style.display = "block";
  }
}
</script>
</body>
</html>
