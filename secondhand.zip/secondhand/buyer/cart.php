<?php
include('../config.php');
session_start();

// যদি login করা না থাকে, login page এ redirect করবে
if (!isset($_SESSION['email'])) {
    header("Location: ../visitor/login.php"); // Assuming login is in the visitor folder
    exit();
}


$email = $_SESSION['email'];

// Quantity update handle
if (isset($_POST['update_quantity'])) {
    $ikey = mysqli_real_escape_string($conn, $_POST['ikey']);
    $quantity = intval($_POST['quantity']);

    if ($quantity > 0) {
        // Fetch price first to ensure totalPrice calculation is correct
        $price_check_sql = "SELECT price FROM cart WHERE ikey='$ikey' AND email='$email'";
        $price_result = mysqli_query($conn, $price_check_sql);
        $price_row = mysqli_fetch_assoc($price_result);
        $item_price = $price_row['price'];
        
        $new_total_price = $item_price * $quantity;

        $update_sql = "UPDATE cart SET quantity='$quantity', totalPrice = '$new_total_price' WHERE ikey='$ikey' AND email='$email'";
        mysqli_query($conn, $update_sql);
    }
    header("Location: cart.php"); // Redirect after POST
    exit();
}

// Cart থেকে product delete
if (isset($_GET['delete'])) {
    $ikey = mysqli_real_escape_string($conn, $_GET['delete']);
    $delete_sql = "DELETE FROM cart WHERE ikey='$ikey' AND email='$email'";
    mysqli_query($conn, $delete_sql);
    header("Location: cart.php"); // Redirect after GET
    exit();
}

// Buyer এর cart data fetch
$sql = "SELECT * FROM cart WHERE email='$email'";
$result = mysqli_query($conn, $sql);

// Grand total calculate
$grandTotal = 0;
$cartItems = [];
if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $cartItems[] = $row;
        $grandTotal += $row['totalPrice'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Cart | Buyer</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f9ff;
            margin: 0;
            padding: 0;
            font-size: 1.6rem;
        }
        header {
            background: #004aad;
            color: white;
            padding: 15px;
            text-align: center;
        }
        h1 {
            margin: 0;
            font-size: 3rem;
        }
        .container {
            width: 90%;
            max-width: 1000px;
            margin: 30px auto;
        }
        .cart-card {
            display: grid;
            grid-template-columns: 120px 1fr 180px;
            background: white;
            border-radius: 12px;
            margin-bottom: 15px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            padding: 15px;
            align-items: center;
        }
        .cart-card img {
            width: 100px;
            height: 100px;
            border-radius: 8px;
            object-fit: contain; /* Changed to contain for product images */
            margin-right: 15px;
        }
        .cart-info {
            padding-right: 10px;
        }
        .cart-info h3 {
            margin: 0;
            color: #004aad;
            font-size: 2rem;
        }
        .cart-info p {
            margin: 5px 0;
            color: #555;
            font-size: 1.5rem;
        }
        .cart-actions {
            text-align: right;
        }
        input[type="number"] {
            width: 60px;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 6px;
            text-align: center;
            font-size: 1.6rem;
        }
        .btn {
            display: inline-block;
            background: #004aad;
            color: white;
            padding: 8px 14px;
            margin-top: 8px;
            text-decoration: none;
            border-radius: 8px;
            font-size: 1.5rem;
            cursor: pointer;
            border: none;
            transition: background 0.3s;
        }
        .btn:hover {
            background: #0066ff;
        }
        .btn-danger {
            background: #e63946;
            margin-left: 5px;
        }
        .btn-danger:hover {
            background: #ff4757;
        }
        .summary {
            background: white;
            padding: 25px;
            margin-top: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            text-align: right;
        }
        .summary h2 {
            margin: 0;
            color: #004aad;
            font-size: 2.5rem;
        }
         @media (max-width: 600px) {
            .cart-card {
                grid-template-columns: 1fr;
                text-align: center;
            }
            .cart-card img {
                margin: 0 auto 10px auto;
            }
            .cart-actions {
                text-align: center;
                margin-top: 15px;
            }
            .summary {
                text-align: center;
            }
        }
    </style>
</head>
<body>
<header>
    <h1>🛒 My Shopping Cart</h1>
</header>

<div class="container">
    <?php if (count($cartItems) > 0) { ?>
        <?php foreach ($cartItems as $item) { ?>
            <div class="cart-card">
                <img src="../images/<?php echo htmlspecialchars($item['image']); ?>" alt="Product Image">
                <div class="cart-info">
                    <h3><?php echo htmlspecialchars($item['title']); ?></h3>
                    <p><?php echo htmlspecialchars($item['description']); ?></p>
                    <p><b>Price:</b> ৳<?php echo number_format($item['price'], 2); ?></p>
                    <p><b>Total:</b> ৳<?php echo number_format($item['totalPrice'], 2); ?></p>
                </div>
                <div class="cart-actions">
                    <form method="post" style="display:inline-block;">
                        <input type="hidden" name="ikey" value="<?php echo htmlspecialchars($item['ikey']); ?>">
                        <input type="number" name="quantity" value="<?php echo htmlspecialchars($item['quantity']); ?>" min="1" required>
                        <button type="submit" name="update_quantity" class="btn"><i class="fas fa-sync-alt"></i> Update</button>
                    </form>
                    <a href="?delete=<?php echo htmlspecialchars($item['ikey']); ?>" class="btn btn-danger"><i class="fas fa-trash-alt"></i> Remove</a>
                </div>
            </div>
        <?php } ?>

        <div class="summary">
            <h2>Grand Total: ৳<?php echo number_format($grandTotal, 2); ?></h2>
            <a href="checkout.php" class="btn">Proceed to Checkout <i class="fas fa-arrow-right"></i></a>
        </div>
    <?php } else { ?>
        <p style="text-align:center; font-size:2rem; color:#004aad; padding: 50px 0;"><i class="fas fa-shopping-cart"></i> Your cart is empty!</p>
    <?php } ?>
</div>
</body>
</html>