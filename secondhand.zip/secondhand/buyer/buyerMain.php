<?php
include('../config.php');
session_start();
if (!isset($_SESSION['Type']) || $_SESSION['Type'] != 'Buyer') {
    header("Location: ../visitor/login.php");
    exit();
}
$email = $_SESSION['email'];

$sql="SELECT * FROM product WHERE shelf='on' ORDER BY price;";
$result=$conn->query($sql);

$sqli = "SELECT COUNT(*) AS countquantity FROM cart WHERE email='$email'";
$duration = $conn->query($sqli);
$record = $duration->fetch_array();
$totalquantity = $record['countquantity'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>2nd Hand | Welcome!</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f8f9fa;
    }
    /* Navbar */
    .header {
      background-color: #ffffff;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      position: sticky;
      top: 0;
      z-index: 1000;
    }
    .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 12px 20px;
    }
    .navbar-brand {
      font-size: 28px;
      font-weight: bold;
      background: linear-gradient(45deg, #007BFF, #00C6FF);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      text-decoration: none;
    }
    .navbar-list {
      list-style: none;
      display: flex;
      gap: 15px;
      margin: 0;
      padding: 0;
    }
    .navbar-link {
      text-decoration: none;
      color: #007BFF;
      font-weight: 500;
      padding: 8px 14px;
      border: 2px solid #007BFF;
      border-radius: 6px;
      transition: all 0.3s ease;
    }
    .navbar-link:hover {
      background-color: #007BFF;
      color: #fff;
    }
    #lblCartCount {
      font-size: 12px;
      background: #ff0000;
      color: #fff;
      padding: 2px 6px;
      border-radius: 50%;
      vertical-align: top;
      margin-left: -6px;
    }

    /* Slideshow */
    .slideshow-container {
      max-width: 100%;
      position: relative;
      margin: 0 auto;
    }
    .mySlides {
      display: none;
    }
    .mySlides img {
      width: 100%;
      border-radius: 8px;
    }
    .dot {
      height: 12px;
      width: 12px;
      margin: 0 3px;
      background-color: #ccc;
      border-radius: 50%;
      display: inline-block;
      transition: background-color 0.6s ease;
    }
    .active {
      background-color: #007BFF;
    }

    /* Products */
    .product-container {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
      gap: 20px;
      padding: 30px;
      max-width: 1200px;
      margin: auto;
    }
    .product-card {
      background: #fff;
      border-radius: 10px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
      padding: 15px;
      text-align: center;
      transition: transform 0.2s ease;
    }
    .product-card:hover {
      transform: translateY(-5px);
    }
    .product-card img {
      width: 100%;
      height: 180px;
      object-fit: cover;
      border-radius: 8px;
    }
    .product-card h2 {
      font-size: 18px;
      margin: 10px 0 5px;
      color: #333;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .product-card p {
      color: #007BFF;
      font-weight: bold;
      margin-bottom: 10px;
    }
    .product-card a {
      display: inline-block;
      padding: 8px 14px;
      background-color: #007BFF;
      color: #fff;
      text-decoration: none;
      border-radius: 5px;
      transition: 0.3s;
    }
    .product-card a:hover {
      background-color: #0056b3;
    }

    footer {
      text-align: center;
      padding: 15px;
      background-color: #f8f9fa;
      margin-top: 30px;
    }
  </style>
</head>
<body>

<header class="header">
  <nav class="navbar">
    <a href="buyerMain.php" class="navbar-brand">SecondHand Marketplace</a>
    <ul class="navbar-list">
      <!--<li><a href="../seller/sellerMain.php" class="navbar-link">Seller Centre</a></li>-->
      <li><a href="buyerMain.php" class="navbar-link">Home</a></li>
      <li><a href="buyerProduct.php" class="navbar-link">Product</a></li>
      <li><a href="order.php" class="navbar-link">Order</a></li>
      <li><a href="buyerProfile.php" class="navbar-link">Profile</a></li>
      <li><a href="about_us.php" class="navbar-link">About</a></li>
      <li><a href="chat.php" class="navbar-link"><i class="fa fa-comment"></i></a></li>
      <li>
        <a href="cart.php" class="navbar-link">
          <i class="fa fa-shopping-cart"></i> 
          <span id='lblCartCount'><?php echo $totalquantity; ?></span>
        </a>
      </li>
      <li><a href="../logout.php" class="navbar-link">Logout</a></li>
    </ul>
  </nav>
</header>

<!-- Slideshow -->
<div class="slideshow-container">
  <div class="mySlides fade"><img src="../images/logo/second1.jpg"></div>
  <div class="mySlides fade"><img src="../images/logo/second2.jpg"></div>
  <div class="mySlides fade"><img src="../images/logo/second3.jpg"></div>
</div>
<div style="text-align:center; margin-top:10px;">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
</div>

<!-- Products -->
<main>
  <div class="product-container">
    <?php
      if ($result->num_rows > 0) {    
        while($row = $result->fetch_assoc()) {
          $id=$row['id'];
          $title=$row['title'];
          $price=$row['price'];
          $image=$row['image'];
    ?>
    <div class="product-card">
      <img src="../images/<?php echo $image;?>" alt="">
      <h2><?php echo $title;?></h2>
      <p>RM <?php echo $price;?></p>
      <a href='product_detail.php?pid=<?php echo $id;?>'>Check Details</a>
    </div>
    <?php }} ?>
  </div>
</main>

<footer>
  <p>Copyright &copy; <script>document.write(new Date().getFullYear());</script> Second Hand Shopping Platform</p>
</footer>

<script>
var slideIndex = 0;
showSlides();
function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) { slides[i].style.display = "none"; }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}
  for (i = 0; i < dots.length; i++) { dots[i].className = dots[i].className.replace(" active", ""); }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 2000);
}
</script>
</body>
</html>
