<?php
include '../config.php';
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: ../login.php");
    exit();
}
$email = $_SESSION['email'];

// cart quantity
$sqli = "SELECT COUNT(*) AS countquantity FROM cart WHERE email='$email'";
$duration = $conn->query($sqli);
$record = $duration->fetch_array();
$totalquantity = $record['countquantity'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Chat | Buyer</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<style>
    body {
        background-color: #f5f8fc;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        margin: 0;
    }
    /* Navbar */
    .header {
        background-color: #ffffff;
        box-shadow: 0 2px 6px rgba(0,0,0,0.1);
        position: sticky;
        top: 0;
        z-index: 100;
    }
    .navbar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px 25px;
    }
    .navbar-brand {
        font-size: 26px;
        font-weight: bold;
        background: linear-gradient(45deg, #007BFF, #00C6FF);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-decoration: none;
    }
    .navbar-list {
        list-style: none;
        display: flex;
        gap: 12px;
        margin: 0;
        padding: 0;
        flex-wrap: wrap;
    }
    .navbar-link {
        text-decoration: none;
        color: #007BFF;
        font-weight: 500;
        padding: 8px 14px;
        border: 2px solid #007BFF;
        border-radius: 6px;
        transition: 0.3s;
        font-size: 14px;
    }
    .navbar-link:hover {
        background-color: #007BFF;
        color: #fff;
    }
    #lblCartCount {
        font-size: 12px;
        background: #ff0000;
        color: #fff;
        padding: 2px 6px;
        border-radius: 50%;
        vertical-align: top;
        margin-left: -6px;
    }

    /* Chat Section */
    .chat-container {
        max-width: 900px;
        margin: 30px auto;
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        display: flex;
        flex-direction: column;
        height: 75vh;
    }
    .chat-header {
        background: #007BFF;
        color: #fff;
        padding: 15px;
        border-top-left-radius: 12px;
        border-top-right-radius: 12px;
        font-weight: bold;
    }
    .chat-box {
        flex: 1;
        padding: 15px;
        overflow-y: auto;
    }
    .message {
        margin: 8px 0;
        padding: 10px 15px;
        border-radius: 18px;
        max-width: 65%;
        word-wrap: break-word;
    }
    .from-me {
        background: #007BFF;
        color: #fff;
        margin-left: auto;
        text-align: right;
    }
    .from-them {
        background: #e9ecef;
        color: #333;
        margin-right: auto;
        text-align: left;
    }
    .chat-input {
        display: flex;
        border-top: 1px solid #ddd;
    }
    .chat-input input {
        flex: 1;
        border: none;
        padding: 12px;
        border-radius: 0 0 0 12px;
        outline: none;
        font-size: 15px;
    }
    .chat-input button {
        border: none;
        background: #007BFF;
        color: #fff;
        padding: 12px 20px;
        border-radius: 0 0 12px 0;
        cursor: pointer;
        transition: 0.3s;
    }
    .chat-input button:hover {
        background: #0056b3;
    }

    footer {
        text-align: center;
        padding: 15px;
        background-color: #f8f9fa;
        margin-top: 40px;
    }
</style>
</head>
<body>
<header class="header">
    <nav class="navbar">
        <a href="buyerMain.php" class="navbar-brand">SecondHand Marketplace</a>
        <ul class="navbar-list">
            <!--<li><a href="../seller/sellerMain.php" class="navbar-link">Seller Centre</a></li>-->
            <li><a href="buyerMain.php" class="navbar-link">Home</a></li>
            <li><a href="buyerProduct.php" class="navbar-link">Product</a></li>
            <li><a href="order.php" class="navbar-link">Order</a></li>
            <li><a href="buyerProfile.php" class="navbar-link">Profile</a></li>
            <li><a href="about_us.php" class="navbar-link">About</a></li>
            <li><a href="chat.php" class="navbar-link" style="background:#007BFF;color:#fff;"><i class="fa fa-comment"></i></a></li>
            <li>
                <a href="cart.php" class="navbar-link">
                    <i class="fa fa-shopping-cart"></i> 
                    <span id='lblCartCount'><?php echo $totalquantity; ?></span>
                </a>
            </li>
            <li><a href="../logout.php" class="navbar-link">Logout</a></li>
        </ul>
    </nav>
</header>

<div class="chat-container">
    <div class="chat-header">
        Chat with Seller
    </div>
    <div class="chat-box" id="chat-box"></div>
    <form id="chatForm" class="chat-input">
        <input type="text" id="message" name="message" placeholder="Type your message..." required>
        <button type="submit"><i class="fa fa-paper-plane"></i></button>
    </form>
</div>

<footer>
    <p>&copy; <script>document.write(new Date().getFullYear());</script> Second Hand Shopping Platform</p>
</footer>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function(){
    function loadChat(){
        $.ajax({
            url: "fetch_chat.php",
            method: "POST",
            data: {email: "<?php echo $email; ?>"},
            success: function(data){
                $("#chat-box").html(data);
                $("#chat-box").scrollTop($("#chat-box")[0].scrollHeight);
            }
        });
    }
    loadChat();
    setInterval(loadChat, 3000);

    $("#chatForm").on("submit", function(e){
        e.preventDefault();
        $.ajax({
            url: "send_chat.php",
            method: "POST",
            data: {message: $("#message").val(), from_id: "<?php echo $email; ?>"},
            success: function(){
                $("#message").val("");
                loadChat();
            }
        });
    });
});
</script>
</body>
</html>
