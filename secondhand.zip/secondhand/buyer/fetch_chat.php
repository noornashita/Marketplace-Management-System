<?php
include '../config.php';
session_start();
$email = $_SESSION['email'];

// Show buyer messages (from_id = buyer) and seller replies (to_id = buyer)
$sql = "SELECT * FROM chats WHERE from_id='$email' OR to_id='$email' ORDER BY created_at ASC";
$result = mysqli_query($conn, $sql);


while($row = mysqli_fetch_assoc($result)){
    $class = ($row['from_id'] == $email) ? "from-me" : "from-them";
    echo "<div class='message $class'>{$row['message']}<br><small style='font-size:10px;color:#666;'>{$row['created_at']}</small></div>";
}
?>
