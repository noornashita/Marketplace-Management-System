<?php
include '../config.php';
session_start();
$email = $_SESSION['email'];


if(isset($_POST['message'])){
    $msg = mysqli_real_escape_string($conn, $_POST['message']);
    $from = $_POST['from_id'];
    // Here we assume all buyer chats go to a "seller" admin email (edit if needed)
    $to = "admin@seller.com";

    $sql = "INSERT INTO chats (from_id, to_id, message) VALUES ('$from', '$to', '$msg')";
    mysqli_query($conn, $sql);
}
?>
