<?php
include('../config.php');
session_start();
$email = $_SESSION['email'];

$sqli = "SELECT COUNT(*) AS countquantity FROM cart WHERE email='$email'";
$duration = $conn->query($sqli);
$record = $duration->fetch_array();
$totalquantity = $record['countquantity'];
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>2nd Hand | About Us</title>

    <link rel="stylesheet" href="../css/menu.css">
    <link rel="stylesheet" href="../css/slideshow.css">
    <link rel="stylesheet" href="../css/product_slider.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <style>
        body {
            background-color: #fff;
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        /* Header & Navbar */
        .header {
            background-color: #ffffff;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 20px;
            max-width: 1200px;
            margin: 0 auto;
        }
        .navbar-brand {
            font-size: 26px;
            font-weight: bold;
            background: linear-gradient(45deg, #007BFF, #00C6FF);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-decoration: none;
            transition: transform 0.3s ease;
        }
        .navbar-brand:hover {
            transform: scale(1.05);
        }

        .navbar-menu {
            display: flex;
            align-items: center;
        }
        .navbar-list {
            list-style: none;
            display: flex;
            gap: 15px;
            margin: 0;
            padding: 0;
        }
        .navbar-link {
            text-decoration: none;
            color: #007BFF;
            font-weight: 500;
            padding: 8px 14px;
            border: 2px solid #007BFF;
            border-radius: 6px;
            transition: all 0.3s ease;
        }
        .navbar-link:hover {
            background-color: #007BFF;
            color: #fff;
        }

        /* Badge for cart */
        #lblCartCount {
            font-size: 12px;
            background: red;
            color: white;
            padding: 1px 5px;
            vertical-align: top;
            margin-left: -5px;
            border-radius: 9px;
        }

        .navbar-toggler {
            display: none;
            background: none;
            border: none;
            font-size: 22px;
        }

        @media (max-width: 768px) {
            .navbar-menu {
                display: none;
                flex-direction: column;
                background-color: #fff;
                position: absolute;
                top: 60px;
                right: 0;
                width: 200px;
                border: 1px solid #ddd;
                padding: 10px 0;
            }
            .navbar-menu.active { display: flex; }
            .navbar-list { flex-direction: column; gap: 10px; }
            .navbar-link { text-align: center; }
            .navbar-toggler { display: block; cursor: pointer; }
        }

        /* About Section */
        .about-section {
            padding: 40px 20px;
            text-align: center;
            background: linear-gradient(45deg, #007BFF, #00C6FF);
            color: white;
            font-size: 28px;
            font-weight: bold;
            letter-spacing: 1px;
        }

        /* Cards container */
        .row {
            max-width: 1200px;
            margin: 30px auto;
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
        }
        .column {
            flex: 1 1 30%;
            max-width: 30%;
        }
        .card {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            overflow: hidden;
            transition: transform 0.3s ease;
        }
        .card:hover {
            transform: translateY(-6px);
        }
        .card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }
        .card .container {
            padding: 15px 20px;
            text-align: center;
        }
        .card h2 {
            margin: 10px 0;
            font-size: 20px;
            color: #007BFF;
        }
        .card p {
            font-size: 14px;
            color: #555;
            margin-bottom: 8px;
        }

        /* Responsive adjustments */
        @media screen and (max-width: 960px) {
            .column { max-width: 45%; flex: 1 1 45%; }
        }
        @media screen and (max-width: 650px) {
            .column { max-width: 100%; flex: 1 1 100%; }
            .about-section { font-size: 22px; padding: 25px; }
        }

        /* Footer */
        footer {
            text-align: center;
            padding: 15px;
            background-color: #f8f9fa;
            margin-top: 30px;
            border-top: 1px solid #ddd;
            font-size: 14px;
        }
    </style>
</head>

<body>
<header class="header">
    <nav class="navbar">
        <a href="../index.php" class="navbar-brand">SecondHand Marketplace</a>

        <div class="navbar-menu" id="navbarMenu">
            <ul class="navbar-list">
                <!--<li><a href="../seller/sellerMain.php" class="navbar-link" style="font-weight:bold;">Seller Centre</a></li>-->
                <li><a href="buyerMain.php" class="navbar-link">Home</a></li>
                <li><a href="buyerProduct.php" class="navbar-link">Product</a></li>
                <li><a href="order.php" class="navbar-link">Order</a></li>
                <li><a href="buyerProfile.php" class="navbar-link">Profile</a></li>
                <li><a href="about_us.php" class="navbar-link" style="background:#007BFF; color:white;">About</a></li>
                <li><a href="chat.php" class="navbar-link"><i class="fa fa-comment"></i></a></li>
                <li>
                    <a href="cart.php" class="navbar-link">
                        <i class="fa fa-shopping-cart"></i>
                        <span id="lblCartCount"><?php echo $totalquantity; ?></span>
                    </a>
                </li>
                <li><a href="../logout.php" class="navbar-link">Logout</a></li>
            </ul>
        </div>

        <button class="navbar-toggler" id="navbarToggler" aria-label="Toggle menu">
            <i class="fas fa-bars"></i>
        </button>
    </nav>
</header>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const toggler = document.getElementById("navbarToggler");
        const menu = document.getElementById("navbarMenu");
        toggler.addEventListener("click", function() {
            menu.classList.toggle("active");
        });
    });
</script>

<div class="about-section">
    ABOUT US
</div>

<div class="row">
    <div class="column">
        <div class="card">
            <img src="../images/about/buy.jpg" alt="Buy">
            <div class="container">
                <h2>Buy Desired 2nd-Hand Item</h2>
                <p>Find anything second hand through our website.</p>
                <p>Search by keywords, category, and price.</p>
            </div>
        </div>
    </div>

    <div class="column">
        <div class="card">
            <img src="../images/about/sell.jpg" alt="Sell">
            <div class="container">
                <h2>Sell Your Own 2nd-Hand Item</h2>
                <p>Submit your product information for selling.</p>
                <p>Each completed order has 5% commission.</p>
            </div>
        </div>
    </div>
  
    <div class="column">
        <div class="card">
            <img src="../images/about/review.jpg" alt="Review">
            <div class="container">
                <h2>All Products Are Reviewed</h2>
                <p>Admin reviews product information first.</p>
                <p>Once approved, they are listed for selling.</p>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="column">
        <div class="card">
            <img src="../images/about/call.jpeg" alt="Contact">
            <div class="container">
                <h2>Feel Free To Contact Us</h2>
                <p>Email: sanjida@gmail.com</p>
                <p>Phone: 01749607239</p>
            </div>
        </div>
    </div>
</div>

<footer>
    <p>Copyright &copy; <script>document.write(new Date().getFullYear());</script> Second Hand Shopping Platform</p>
</footer>

</body>
</html>
