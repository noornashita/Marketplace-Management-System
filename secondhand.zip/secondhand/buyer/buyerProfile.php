<?php
include('../config.php');
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: ../login.php");
    exit();
}
$email = $_SESSION['email'];


// cart quantity
$sqli = "SELECT COUNT(*) AS countquantity FROM cart WHERE email='$email'";
$duration = $conn->query($sqli);
$record = $duration->fetch_array();
$totalquantity = $record['countquantity'];

// fetch address info
$sql = "SELECT * FROM address WHERE email='$email' ORDER BY id DESC LIMIT 1";
$result = mysqli_query($conn, $sql);
$address = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>My Profile | Buyer</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<style>
    body {
        background-color: #f5f8fc;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        margin: 0;
    }
    /* Navbar */
    .header {
        background-color: #ffffff;
        box-shadow: 0 2px 6px rgba(0,0,0,0.1);
        position: sticky;
        top: 0;
        z-index: 100;
    }
    .navbar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px 25px;
        flex-wrap: wrap;
    }
    .navbar-brand {
        font-size: 26px;
        font-weight: bold;
        background: linear-gradient(45deg, #007BFF, #00C6FF);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-decoration: none;
    }
    .navbar-list {
        list-style: none;
        display: flex;
        gap: 12px;
        margin: 0;
        padding: 0;
        flex-wrap: wrap;
    }
    .navbar-link {
        text-decoration: none;
        color: #007BFF;
        font-weight: 500;
        padding: 8px 14px;
        border: 2px solid #007BFF;
        border-radius: 6px;
        transition: 0.3s;
        font-size: 14px;
    }
    .navbar-link:hover {
        background-color: #007BFF;
        color: #fff;
    }
    #lblCartCount {
        font-size: 12px;
        background: #ff0000;
        color: #fff;
        padding: 2px 6px;
        border-radius: 50%;
        vertical-align: top;
        margin-left: -6px;
    }

    /* Profile Card */
    .profile-container {
        max-width: 700px;
        margin: 40px auto;
        background: #fff;
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    .profile-header {
        text-align: center;
        margin-bottom: 20px;
    }
    .profile-header h2 {
        color: #007BFF;
        margin-bottom: 8px;
    }
    .profile-details p {
        font-size: 15px;
        margin: 8px 0;
    }
    .form-section {
        margin-top: 25px;
    }
    .form-section h3 {
        margin-bottom: 15px;
        color: #007BFF;
    }
    .form-group {
        margin-bottom: 12px;
    }
    .form-group label {
        display: block;
        font-weight: 500;
        margin-bottom: 6px;
    }
    .form-group input {
        width: 100%;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 6px;
        font-size: 14px;
    }
    .btn-primary {
        background-color: #007BFF;
        border: none;
        color: #fff;
        padding: 10px 18px;
        border-radius: 6px;
        cursor: pointer;
        font-size: 15px;
    }
    .btn-primary:hover {
        background-color: #0056b3;
    }
    footer {
        text-align: center;
        padding: 15px;
        background-color: #f8f9fa;
        margin-top: 40px;
    }
</style>
</head>
<body>
<header class="header">
    <nav class="navbar">
        <a href="buyerMain.php" class="navbar-brand">SecondHand Marketplace</a>
        <ul class="navbar-list">
           <!-- <li><a href="../seller/sellerMain.php" class="navbar-link">Seller Centre</a></li>-->
            <li><a href="buyerMain.php" class="navbar-link">Home</a></li>
            <li><a href="buyerProduct.php" class="navbar-link">Product</a></li>
            <li><a href="order.php" class="navbar-link">Order</a></li>
            <li><a href="buyerProfile.php" class="navbar-link" style="background:#007BFF;color:#fff;">Profile</a></li>
            <li><a href="about_us.php" class="navbar-link">About</a></li>
            <li><a href="chat.php" class="navbar-link"><i class="fa fa-comment"></i></a></li>
            <li>
                <a href="cart.php" class="navbar-link">
                    <i class="fa fa-shopping-cart"></i> 
                    <span id='lblCartCount'><?php echo $totalquantity; ?></span>
                </a>
            </li>
            <li><a href="../logout.php" class="navbar-link">Logout</a></li>
        </ul>
    </nav>
</header>

<div class="profile-container">
    <div class="profile-header">
        <h2>My Profile</h2>
        <p><?php echo $email; ?></p>
    </div>
    <div class="profile-details">
        <p><strong>Home Address:</strong> <?php echo $address ? $address['home_address'] : 'Not Added'; ?></p>
        <p><strong>Street:</strong> <?php echo $address ? $address['street'] : 'Not Added'; ?></p>
        <p><strong>Area:</strong> <?php echo $address ? $address['area'] : 'Not Added'; ?></p>
        <p><strong>Phone Number:</strong> <?php echo $address ? $address['phone_number'] : 'Not Added'; ?></p>
    </div>

    <div class="form-section">
        <h3><?php echo $address ? 'Update Address' : 'Add Address'; ?></h3>
        <form id="addressForm">
            <div class="form-group">
                <label>Home Address</label>
                <input type="text" name="home_address" value="<?php echo $address ? $address['home_address'] : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Street</label>
                <input type="text" name="street" value="<?php echo $address ? $address['street'] : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Area</label>
                <input type="text" name="area" value="<?php echo $address ? $address['area'] : ''; ?>" required>
            </div>
            <div class="form-group">
                <label>Phone Number</label>
                <input type="text" name="phone_number" value="<?php echo $address ? $address['phone_number'] : ''; ?>" required>
            </div>
            <button type="submit" class="btn-primary">Save</button>
        </form>
    </div>
</div>

<footer>
    <p>&copy; <script>document.write(new Date().getFullYear());</script> Second Hand Shopping Platform</p>
</footer>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$("#addressForm").submit(function(e){
    e.preventDefault();
    $.ajax({
        type: "POST",
        url: "add_user.php",
        data: $(this).serialize(),
        dataType: "json",
        success: function(response){
            if(response.status == 'true'){
                alert("Address saved successfully!");
                location.reload();
            } else {
                alert("Failed to save address!");
            }
        }
    });
});
</script>
</body>
</html>
