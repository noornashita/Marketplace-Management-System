<?php
include '../config.php';
session_start();
$email = $_SESSION['email'];

// cart quantity
$sqli = "SELECT COUNT(*) AS countquantity FROM cart WHERE email='$email'";
$duration = $conn->query($sqli);
$record = $duration->fetch_array();
$totalquantity = $record['countquantity'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>My Orders | Buyer</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">

<style>
    body {
        background-color: #f5f8fc;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        margin: 0;
    }
    /* Navbar */
    .header {
        background-color: #ffffff;
        box-shadow: 0 2px 6px rgba(0,0,0,0.1);
        position: sticky;
        top: 0;
        z-index: 100;
    }
    .navbar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px 25px;
    }
    .navbar-brand {
        font-size: 26px;
        font-weight: bold;
        background: linear-gradient(45deg, #007BFF, #00C6FF);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-decoration: none;
    }
    .navbar-list {
        list-style: none;
        display: flex;
        gap: 12px;
        margin: 0;
        padding: 0;
        flex-wrap: wrap;
    }
    .navbar-link {
        text-decoration: none;
        color: #007BFF;
        font-weight: 500;
        padding: 8px 14px;
        border: 2px solid #007BFF;
        border-radius: 6px;
        transition: 0.3s;
        font-size: 14px;
    }
    .navbar-link:hover {
        background-color: #007BFF;
        color: #fff;
    }
    #lblCartCount {
        font-size: 12px;
        background: #ff0000;
        color: #fff;
        padding: 2px 6px;
        border-radius: 50%;
        vertical-align: top;
        margin-left: -6px;
    }

    /* Table */
    .chris {
        margin: 20px 40px 50px 40px;
        background: #fff;
        padding: 25px;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    table.dataTable {
        width: 100% !important;
        border-collapse: collapse;
    }
    table.dataTable thead th {
        background-color: #007BFF;
        color: #fff;
        text-align: center;
    }
    table.dataTable tbody td {
        text-align: center;
    }

    footer {
        text-align: center;
        padding: 15px;
        background-color: #f8f9fa;
        margin-top: 40px;
    }
</style>
</head>
<body>
<header class="header">
    <nav class="navbar">
        <a href="buyerMain.php" class="navbar-brand">SecondHand Marketplace</a>
        <ul class="navbar-list">
           <!-- <li><a href="../seller/sellerMain.php" class="navbar-link">Seller Centre</a></li>-->
            <li><a href="buyerMain.php" class="navbar-link">Home</a></li>
            <li><a href="buyerProduct.php" class="navbar-link">Product</a></li>
            <li><a href="order.php" class="navbar-link" style="background:#007BFF;color:#fff;">Order</a></li>
            <li><a href="buyerProfile.php" class="navbar-link">Profile</a></li>
            <li><a href="about_us.php" class="navbar-link">About</a></li>
            <li><a href="chat.php" class="navbar-link"><i class="fa fa-comment"></i></a></li>
            <li>
                <a href="cart.php" class="navbar-link">
                    <i class="fa fa-shopping-cart"></i> 
                    <span id='lblCartCount'><?php echo $totalquantity; ?></span>
                </a>
            </li>
            <li><a href="../logout.php" class="navbar-link">Logout</a></li>
        </ul>
    </nav>
</header>

<div class="chris">
    <h2 style="text-align:center; color:#007BFF; margin-bottom:20px;">My Orders</h2>
    <table id="example" class="display">
        <thead>
            <tr>
                <th>Date & Time</th>
                <th>Transaction ID</th>
                <th>Seller</th>
                <th>Address</th>
                <th>Image</th>
                <th>Product</th>
                <th>Total Price (BDT)</th>
                <th>Payment Status</th>
                <th>Order Status</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $query = "SELECT * FROM order_list WHERE custemail = '$email' ORDER BY time DESC";
        $result = mysqli_query($conn, $query);
        while($row = mysqli_fetch_array($result)){
        ?>
            <tr>
                <td><?php echo $row['time'];?></td>
                <td><?php echo $row['transaction_id'];?></td>
                <td><?php echo $row['seller_id'];?></td>
                <td><?php echo $row['delivery_address'];?></td>
                <td style="width:120px;"><img src="../images/<?php echo $row['image'] ?>" width="100%"></td>
                <td><?php echo $row['title'];?><br><b>x<?php echo $row['quantity'];?></b></td>
                <td><?php echo $row['totalPrice'];?></td>
                <td><?php echo $row['payment_status'];?></td>
                <td><?php echo $row['order_status'];?></td>
            </tr>
        <?php } ?>
        </tbody>
        <tfoot>
            <tr>
                <th>Date & Time</th>
                <th>Transaction ID</th>
                <th>Seller</th>
                <th>Address</th>
                <th>Image</th>
                <th>Product</th>
                <th>Total Price (BDT)</th>
                <th>Payment Status</th>
                <th>Order Status</th>
            </tr>
        </tfoot>
    </table>
</div>

<footer>
    <p>&copy; <script>document.write(new Date().getFullYear());</script> Second Hand Shopping Platform</p>
</footer>

<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
<script>
$(document).ready(function() {
    $('#example').DataTable();
});
</script>
</body>
</html>
