<?php
include('../config.php');
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: ../visitor/login.php");
    exit();
}


$email = $_SESSION['email'];
$grandTotal = 0;
$cartItems = [];
$userAddress = [];

// Fetch Cart Data and calculate Grand Total
$sql_cart = "SELECT * FROM cart WHERE email='$email'";
$result_cart = mysqli_query($conn, $sql_cart);

if ($result_cart && mysqli_num_rows($result_cart) > 0) {
    while ($row = mysqli_fetch_assoc($result_cart)) {
        $cartItems[] = $row;
        $grandTotal += $row['totalPrice'];
    }
} else {
    // If cart is empty, redirect to cart page
    // header("Location: cart.php");
    // exit();
}

// Fetch User's existing address data
$sql_user_data = "SELECT address, street, area, phone_number FROM users WHERE email='$email'";
$result_user_data = mysqli_query($conn, $sql_user_data);

if ($result_user_data && mysqli_num_rows($result_user_data) > 0) {
    $userAddress = mysqli_fetch_assoc($result_user_data);
} else {
    $sql_address_data = "SELECT home_address AS address, street, area, phone_number FROM address WHERE email='$email' LIMIT 1";
    $result_address_data = mysqli_query($conn, $sql_address_data);
    if ($result_address_data && mysqli_num_rows($result_address_data) > 0) {
        $userAddress = mysqli_fetch_assoc($result_address_data);
    }
}

// Default values for form fields
$default_address = htmlspecialchars($userAddress['address'] ?? '');
$default_street = htmlspecialchars($userAddress['street'] ?? '');
$default_area = htmlspecialchars($userAddress['area'] ?? '');
$default_phone = htmlspecialchars($userAddress['phone_number'] ?? '');


// Handle Order Submission
if (isset($_POST['place_order'])) {
    
    if (empty($cartItems)) {
        echo '<script>alert("Your cart is empty. Please add products first."); window.location.href = "cart.php";</script>';
        exit;
    }

    $delivery_address = mysqli_real_escape_string($conn, $_POST['delivery_address']);
    $street = mysqli_real_escape_string($conn, $_POST['street']);
    $area = mysqli_real_escape_string($conn, $_POST['area']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone_number']);
    $payment_method = mysqli_real_escape_string($conn, $_POST['payment_method']);
    
    $order_status = "Pending";
    $payment_status = ($payment_method == "COD") ? "Pending" : "Unpaid";
    
    $transaction_id = uniqid('TXN_' . time() . '_');

    mysqli_begin_transaction($conn);
    $success = true;
    $error_message = "";

    foreach ($cartItems as $item) {
        $product_id = mysqli_real_escape_string($conn, $item['id']);
        $seller_id = mysqli_real_escape_string($conn, $item['seller_id']);
        $item_price = floatval($item['price']);
        $item_total_price = floatval($item['totalPrice']);
        $item_quantity = intval($item['quantity']);
        $item_title = mysqli_real_escape_string($conn, $item['title']);
        $item_category = mysqli_real_escape_string($conn, $item['category']);
        $item_image = mysqli_real_escape_string($conn, $item['image']);
        $item_description = mysqli_real_escape_string($conn, $item['description']);
        
        // **FIXED SQL INSERT STATEMENT (Ensuring 17 columns match 17 values)**
        $insert_order_sql = "INSERT INTO order_list (
            transaction_id, id, title, category, quantity, price, image, description, totalPrice, custemail, 
            payment_method, payment_status, order_status, delivery_address, street, area, seller_id
        ) VALUES (
            '$transaction_id', 
            '$product_id', 
            '$item_title', 
            '$item_category', 
            '$item_quantity', 
            '$item_price', 
            '$item_image', 
            '$item_description', 
            '$item_total_price', 
            '$email', 
            '$payment_method', 
            '$payment_status', 
            '$order_status', 
            '$delivery_address', 
            '$street', 
            '$area', 
            '$seller_id'
        )";

        if (!mysqli_query($conn, $insert_order_sql)) {
            $success = false;
            $error_message = mysqli_error($conn); 
            break;
        }

        // Decrease stock
        $update_stock_sql = "UPDATE product SET quantity = quantity - $item_quantity WHERE id = '$product_id'";
        if (!mysqli_query($conn, $update_stock_sql)) {
            $success = false;
            $error_message = mysqli_error($conn);
            break;
        }
    }

    if ($success) {
        $clear_cart_sql = "DELETE FROM cart WHERE email='$email'";
        mysqli_query($conn, $clear_cart_sql);
        
        mysqli_commit($conn);

        echo '<script type="text/javascript">';
        echo 'alert("Order Placed Successfully! Your Transaction ID is: ' . $transaction_id . '");';
        echo 'window.location.href = "order_history.php";'; // Redirect to order history page
        echo '</script>';
    } else {
        mysqli_rollback($conn);
        
        $debug_alert = "Error placing order. Please try again. DB Error: " . $error_message; 
        
        echo '<script type="text/javascript">';
        echo 'alert("' . $debug_alert . '");'; 
        echo 'window.location.href = "cart.php";'; 
        echo '</script>';
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Checkout | SecondHand Marketplace</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* (CSS styles remain the same) */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f9ff;
            margin: 0;
            padding: 0;
            font-size: 1.6rem;
        }
        .container {
            width: 90%;
            max-width: 1000px;
            margin: 30px auto;
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 30px;
        }
        h1 {
            color: #004aad;
            text-align: center;
            padding: 20px 0;
            margin: 0;
            font-size: 3rem;
        }
        h2 {
            color: #333;
            font-size: 2.2rem;
            border-bottom: 2px solid #ddd;
            padding-bottom: 10px;
            margin-top: 0;
        }
        .checkout-main, .checkout-summary {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: #555;
            font-size: 1.5rem;
        }
        .form-group input, .form-group select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 6px;
            box-sizing: border-box;
            font-size: 1.6rem;
        }
        .product-item {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px dashed #eee;
            font-size: 1.5rem;
        }
        .product-item:last-of-type {
            border-bottom: none;
            margin-bottom: 15px;
        }
        .total-row {
            display: flex;
            justify-content: space-between;
            font-weight: 700;
            font-size: 2rem;
            margin-top: 15px;
            padding-top: 10px;
            border-top: 2px solid #004aad;
        }
        .btn-place-order {
            width: 100%;
            background: #004aad;
            color: white;
            padding: 15px;
            border: none;
            border-radius: 8px;
            font-size: 1.8rem;
            cursor: pointer;
            transition: background 0.3s;
            margin-top: 20px;
        }
        .btn-place-order:hover {
            background: #0066ff;
        }

        @media (max-width: 768px) {
            .container {
                grid-template-columns: 1fr;
                gap: 20px;
                width: 95%;
            }
        }
    </style>
</head>
<body>

<h1><i class="fas fa-truck"></i> Proceed to Checkout</h1>

<div class="container">
    
    <div class="checkout-main">
        <h2>Delivery Information</h2>
        
        <form method="post">
            <div class="form-group">
                <label for="delivery_address">Full Address (House/Holding No.):</label>
                <input type="text" id="delivery_address" name="delivery_address" value="<?php echo $default_address; ?>" required>
            </div>
            
            <div class="form-group">
                <label for="street">Street/Village:</label>
                <input type="text" id="street" name="street" value="<?php echo $default_street; ?>" required>
            </div>
            
            <div class="form-group">
                <label for="area">Area/City:</label>
                <input type="text" id="area" name="area" value="<?php echo $default_area; ?>" required>
            </div>
            
            <div class="form-group">
                <label for="phone_number">Phone Number:</label>
                <input type="text" id="phone_number" name="phone_number" value="<?php echo $default_phone; ?>" required>
            </div>
            
            <h2>Payment Method</h2>
            <div class="form-group">
                <label for="payment_method">Select Payment Option:</label>
                <select id="payment_method" name="payment_method" required>
                    <option value="COD">Cash On Delivery (COD)</option>
                    <option value="Online">Online Payment (e.g., Bkash/Nagad - Setup required)</option>
                </select>
            </div>
            
            <button type="submit" name="place_order" class="btn-place-order">
                Place Order (৳<?php echo number_format($grandTotal, 2); ?>)
            </button>
        </form>
    </div>

    <div class="checkout-summary">
        <h2>Order Summary</h2>
        <?php foreach ($cartItems as $item) { ?>
            <div class="product-item">
                <span class="product-name"><?php echo htmlspecialchars($item['title']); ?> (x<?php echo $item['quantity']; ?>)</span>
                <span class="product-price">৳<?php echo number_format($item['totalPrice'], 2); ?></span>
            </div>
        <?php } ?>
        
        <div class="total-row">
            <span>Grand Total</span>
            <span class="grand-total">৳<?php echo number_format($grandTotal, 2); ?></span>
        </div>
        <p style="font-size:1.2rem; color:#888; text-align:right; margin-top:10px;">(Shipping Fee/Tax not included in this total)</p>
    </div>

</div>
</body>
</html>