<?php
include('../config.php');
session_start();

// Check buyer login
if(!isset($_SESSION['email'])){
  header("Location: ../login.php");
  exit();
}
$email = $_SESSION['email'];

// =========================
// 1. Add to Cart (when clicked)
// =========================
if (isset($_POST['add_to_cart'])) {
    $pid = $_POST['product_id'];

    // Product info fetch
    $pquery = "SELECT * FROM product WHERE id='$pid'";
    $pres = $conn->query($pquery);
    $prow = $pres->fetch_assoc();

    if ($prow) {
        $ikey = uniqid(); // unique key for cart row
        $title = $prow['title'];
        $category = $prow['category'];
        $price = $prow['price'];
        $image = $prow['image'];
        $description = $prow['description'];
        $quantity = 1; // default when adding to cart
        $totalPrice = $price * $quantity;
        $seller_id = $prow['seller_id'];

        // Insert into cart table
        $insert = "INSERT INTO cart 
                   (id, title, category, quantity, price, image, description, totalPrice, email, ikey, seller_id)
                   VALUES 
                   ('$pid', '$title', '$category', '$quantity', '$price', '$image', '$description', '$totalPrice', '$email', '$ikey', '$seller_id')";
        $conn->query($insert);
    }
    header("Location: buyerProduct.php");
    exit();
}

// =========================
// 2. Fetch product list (only shelf='on')
// =========================
$sql="SELECT * FROM product WHERE shelf='on' ORDER BY price;";
$result=$conn->query($sql);

// =========================
// 3. Cart item count
// =========================
$sqli = "SELECT COUNT(*) AS countquantity FROM cart WHERE email='$email'";
$duration = $conn->query($sqli);
$record = $duration->fetch_array();
$totalquantity = $record['countquantity'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Buyer | Products</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f8f9fa;
    }
    /* Navbar */
    .header {
      background-color: #ffffff;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      position: sticky;
      top: 0;
      z-index: 1000;
    }
    .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 12px 20px;
    }
    .navbar-brand {
      font-size: 26px;
      font-weight: bold;
      background: linear-gradient(45deg, #007BFF, #00C6FF);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      text-decoration: none;
    }
    .navbar-list {
      list-style: none;
      display: flex;
      gap: 12px;
      margin: 0;
      padding: 0;
      flex-wrap: wrap;
    }
    .navbar-link {
      text-decoration: none;
      color: #007BFF;
      font-weight: 500;
      padding: 8px 14px;
      border: 2px solid #007BFF;
      border-radius: 6px;
      transition: all 0.3s ease;
      font-size: 14px;
    }
    .navbar-link:hover {
      background-color: #007BFF;
      color: #fff;
    }
    #lblCartCount {
      font-size: 12px;
      background: #ff0000;
      color: #fff;
      padding: 2px 6px;
      border-radius: 50%;
      vertical-align: top;
      margin-left: -6px;
    }

    /* Products */
    .product-container {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
      gap: 20px;
      padding: 30px;
      max-width: 1200px;
      margin: auto;
    }
    .product-card {
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
      padding: 15px;
      text-align: center;
      transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    .product-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    .product-card img {
      width: 100%;
      height: 180px;
      object-fit: cover;
      border-radius: 8px;
    }
    .product-card h2 {
      font-size: 18px;
      margin: 10px 0 5px;
      color: #333;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .product-card p {
      color: #007BFF;
      font-weight: bold;
      margin-bottom: 10px;
    }
    .btn {
      display: inline-block;
      padding: 8px 14px;
      background-color: #007BFF;
      color: #fff;
      text-decoration: none;
      border-radius: 5px;
      transition: 0.3s;
      font-size: 14px;
      margin: 5px 2px;
      border: none;
      cursor: pointer;
    }
    .btn:hover {
      background-color: #0056b3;
    }

    footer {
      text-align: center;
      padding: 15px;
      background-color: #f8f9fa;
      margin-top: 30px;
      font-size: 14px;
      color: #555;
    }
  </style>
</head>
<body>

<header class="header">
  <nav class="navbar">
    <a href="buyerMain.php" class="navbar-brand">SecondHand Marketplace</a>
    <ul class="navbar-list">
      <!--<li><a href="../seller/sellerMain.php" class="navbar-link">Seller Centre</a></li>-->
      <li><a href="buyerMain.php" class="navbar-link">Home</a></li>
      <li><a href="buyerProduct.php" class="navbar-link">Product</a></li>
      <li><a href="order.php" class="navbar-link">Order</a></li>
      <li><a href="buyerProfile.php" class="navbar-link">Profile</a></li>
      <li><a href="about_us.php" class="navbar-link">About</a></li>
      <li><a href="chat.php" class="navbar-link"><i class="fa fa-comment"></i></a></li>
      <li>
        <a href="cart.php" class="navbar-link">
          <i class="fa fa-shopping-cart"></i> 
          <span id='lblCartCount'><?php echo $totalquantity; ?></span>
        </a>
      </li>
      <li><a href="../logout.php" class="navbar-link">Logout</a></li>
    </ul>
  </nav>
</header>

<!-- Products -->
<main>
  <h2 style="text-align:center; margin-top:20px; color:#007BFF;">Available Products</h2>
  <div class="product-container">
    <?php
      if ($result->num_rows > 0) {    
        while($row = $result->fetch_assoc()) {
          $id=$row['id'];
          $title=$row['title'];
          $price=$row['price'];
          $image=$row['image'];
    ?>
    <div class="product-card">
      <img src="../images/<?php echo $image;?>" alt="">
      <h2><?php echo $title;?></h2>
      <p>BDT <?php echo $price;?></p>
      <a class="btn" href='product_detail.php?pid=<?php echo $id;?>'>Check Details</a>
      <form method="POST" style="display:inline;">
        <input type="hidden" name="product_id" value="<?php echo $id; ?>">
        <button type="submit" name="add_to_cart" class="btn"><i class="fa fa-cart-plus"></i> Add to Cart</button>
      </form>
    </div>
    <?php }} else { ?>
      <p style="grid-column:1/-1; text-align:center; color:#555;">No products available.</p>
    <?php } ?>
  </div>
</main>

<footer>
  <p>Copyright &copy; <script>document.write(new Date().getFullYear());</script> Second Hand Shopping Platform</p>
</footer>

</body>
</html>
